<html>
	<head>
		<title> $title </title>
	</head>
	<body>
		<div class="content">
			<div class="post_title">

			</div>
			<div class="post_content">

			</div>
			<div class="post_date">

			</div>
		</div>
		<div class="comment">
			<div class="comment">
				<div class="comment_author">
					$author
				</div>
				<div class="comment_content">
					$comment
				</div>
				<div class="comment_date">
					$date	
				</div>
			</div>
		</div>
	</body>
</html>